﻿Public Class Keyboard
    Private Sub Keyboard_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        tools.send("ESC")
    End Sub

    Private Sub Button77_Click(sender As Object, e As EventArgs) Handles Button77.Click

    End Sub
End Class
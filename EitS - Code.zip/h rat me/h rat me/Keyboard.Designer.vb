﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Keyboard
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.Button3 = New System.Windows.Forms.Button()
        Me.Button4 = New System.Windows.Forms.Button()
        Me.Button5 = New System.Windows.Forms.Button()
        Me.Button6 = New System.Windows.Forms.Button()
        Me.Button7 = New System.Windows.Forms.Button()
        Me.Button8 = New System.Windows.Forms.Button()
        Me.Button9 = New System.Windows.Forms.Button()
        Me.Button10 = New System.Windows.Forms.Button()
        Me.Button11 = New System.Windows.Forms.Button()
        Me.Button12 = New System.Windows.Forms.Button()
        Me.Button13 = New System.Windows.Forms.Button()
        Me.Button16 = New System.Windows.Forms.Button()
        Me.Button14 = New System.Windows.Forms.Button()
        Me.Button15 = New System.Windows.Forms.Button()
        Me.Button17 = New System.Windows.Forms.Button()
        Me.Button18 = New System.Windows.Forms.Button()
        Me.Button19 = New System.Windows.Forms.Button()
        Me.Button20 = New System.Windows.Forms.Button()
        Me.Button21 = New System.Windows.Forms.Button()
        Me.Button22 = New System.Windows.Forms.Button()
        Me.Button23 = New System.Windows.Forms.Button()
        Me.Button24 = New System.Windows.Forms.Button()
        Me.Button25 = New System.Windows.Forms.Button()
        Me.Button26 = New System.Windows.Forms.Button()
        Me.Button27 = New System.Windows.Forms.Button()
        Me.Button28 = New System.Windows.Forms.Button()
        Me.Button29 = New System.Windows.Forms.Button()
        Me.Button30 = New System.Windows.Forms.Button()
        Me.Button31 = New System.Windows.Forms.Button()
        Me.Button32 = New System.Windows.Forms.Button()
        Me.Button33 = New System.Windows.Forms.Button()
        Me.Button34 = New System.Windows.Forms.Button()
        Me.Button35 = New System.Windows.Forms.Button()
        Me.Button36 = New System.Windows.Forms.Button()
        Me.Button37 = New System.Windows.Forms.Button()
        Me.Button38 = New System.Windows.Forms.Button()
        Me.Button39 = New System.Windows.Forms.Button()
        Me.Button40 = New System.Windows.Forms.Button()
        Me.Button41 = New System.Windows.Forms.Button()
        Me.Button42 = New System.Windows.Forms.Button()
        Me.Button43 = New System.Windows.Forms.Button()
        Me.Button44 = New System.Windows.Forms.Button()
        Me.Button45 = New System.Windows.Forms.Button()
        Me.Button46 = New System.Windows.Forms.Button()
        Me.Button47 = New System.Windows.Forms.Button()
        Me.Button48 = New System.Windows.Forms.Button()
        Me.Button49 = New System.Windows.Forms.Button()
        Me.Button50 = New System.Windows.Forms.Button()
        Me.Button51 = New System.Windows.Forms.Button()
        Me.Button52 = New System.Windows.Forms.Button()
        Me.Button53 = New System.Windows.Forms.Button()
        Me.Button54 = New System.Windows.Forms.Button()
        Me.Button55 = New System.Windows.Forms.Button()
        Me.Button56 = New System.Windows.Forms.Button()
        Me.Button57 = New System.Windows.Forms.Button()
        Me.Button58 = New System.Windows.Forms.Button()
        Me.Button59 = New System.Windows.Forms.Button()
        Me.Button60 = New System.Windows.Forms.Button()
        Me.Button61 = New System.Windows.Forms.Button()
        Me.Button62 = New System.Windows.Forms.Button()
        Me.Button63 = New System.Windows.Forms.Button()
        Me.Button65 = New System.Windows.Forms.Button()
        Me.Button66 = New System.Windows.Forms.Button()
        Me.Button67 = New System.Windows.Forms.Button()
        Me.Button68 = New System.Windows.Forms.Button()
        Me.Button69 = New System.Windows.Forms.Button()
        Me.Button70 = New System.Windows.Forms.Button()
        Me.Button71 = New System.Windows.Forms.Button()
        Me.Button72 = New System.Windows.Forms.Button()
        Me.Button73 = New System.Windows.Forms.Button()
        Me.Button74 = New System.Windows.Forms.Button()
        Me.Button75 = New System.Windows.Forms.Button()
        Me.Button76 = New System.Windows.Forms.Button()
        Me.Button77 = New System.Windows.Forms.Button()
        Me.Button78 = New System.Windows.Forms.Button()
        Me.Button79 = New System.Windows.Forms.Button()
        Me.Button80 = New System.Windows.Forms.Button()
        Me.Button81 = New System.Windows.Forms.Button()
        Me.Button82 = New System.Windows.Forms.Button()
        Me.Button83 = New System.Windows.Forms.Button()
        Me.Button84 = New System.Windows.Forms.Button()
        Me.Button85 = New System.Windows.Forms.Button()
        Me.Button64 = New System.Windows.Forms.Button()
        Me.Button86 = New System.Windows.Forms.Button()
        Me.Button87 = New System.Windows.Forms.Button()
        Me.Button88 = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(12, 12)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(35, 35)
        Me.Button1.TabIndex = 0
        Me.Button1.Text = "Esc"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'Button2
        '
        Me.Button2.Location = New System.Drawing.Point(80, 12)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(35, 35)
        Me.Button2.TabIndex = 1
        Me.Button2.Text = "F1"
        Me.Button2.UseVisualStyleBackColor = True
        '
        'Button3
        '
        Me.Button3.Location = New System.Drawing.Point(121, 12)
        Me.Button3.Name = "Button3"
        Me.Button3.Size = New System.Drawing.Size(35, 35)
        Me.Button3.TabIndex = 2
        Me.Button3.Text = "F2"
        Me.Button3.UseVisualStyleBackColor = True
        '
        'Button4
        '
        Me.Button4.Location = New System.Drawing.Point(162, 12)
        Me.Button4.Name = "Button4"
        Me.Button4.Size = New System.Drawing.Size(35, 35)
        Me.Button4.TabIndex = 3
        Me.Button4.Text = "F3"
        Me.Button4.UseVisualStyleBackColor = True
        '
        'Button5
        '
        Me.Button5.Location = New System.Drawing.Point(203, 12)
        Me.Button5.Name = "Button5"
        Me.Button5.Size = New System.Drawing.Size(35, 35)
        Me.Button5.TabIndex = 4
        Me.Button5.Text = "F4"
        Me.Button5.UseVisualStyleBackColor = True
        '
        'Button6
        '
        Me.Button6.Location = New System.Drawing.Point(406, 12)
        Me.Button6.Name = "Button6"
        Me.Button6.Size = New System.Drawing.Size(35, 35)
        Me.Button6.TabIndex = 8
        Me.Button6.Text = "F8"
        Me.Button6.UseVisualStyleBackColor = True
        '
        'Button7
        '
        Me.Button7.Location = New System.Drawing.Point(365, 12)
        Me.Button7.Name = "Button7"
        Me.Button7.Size = New System.Drawing.Size(35, 35)
        Me.Button7.TabIndex = 7
        Me.Button7.Text = "F7"
        Me.Button7.UseVisualStyleBackColor = True
        '
        'Button8
        '
        Me.Button8.Location = New System.Drawing.Point(324, 12)
        Me.Button8.Name = "Button8"
        Me.Button8.Size = New System.Drawing.Size(35, 35)
        Me.Button8.TabIndex = 6
        Me.Button8.Text = "F6"
        Me.Button8.UseVisualStyleBackColor = True
        '
        'Button9
        '
        Me.Button9.Location = New System.Drawing.Point(283, 12)
        Me.Button9.Name = "Button9"
        Me.Button9.Size = New System.Drawing.Size(35, 35)
        Me.Button9.TabIndex = 5
        Me.Button9.Text = "F5"
        Me.Button9.UseVisualStyleBackColor = True
        '
        'Button10
        '
        Me.Button10.Location = New System.Drawing.Point(599, 12)
        Me.Button10.Name = "Button10"
        Me.Button10.Size = New System.Drawing.Size(35, 35)
        Me.Button10.TabIndex = 12
        Me.Button10.Text = "F12"
        Me.Button10.UseVisualStyleBackColor = True
        '
        'Button11
        '
        Me.Button11.Location = New System.Drawing.Point(558, 12)
        Me.Button11.Name = "Button11"
        Me.Button11.Size = New System.Drawing.Size(35, 35)
        Me.Button11.TabIndex = 11
        Me.Button11.Text = "F11"
        Me.Button11.UseVisualStyleBackColor = True
        '
        'Button12
        '
        Me.Button12.Location = New System.Drawing.Point(517, 12)
        Me.Button12.Name = "Button12"
        Me.Button12.Size = New System.Drawing.Size(35, 35)
        Me.Button12.TabIndex = 10
        Me.Button12.Text = "F10"
        Me.Button12.UseVisualStyleBackColor = True
        '
        'Button13
        '
        Me.Button13.Location = New System.Drawing.Point(476, 12)
        Me.Button13.Name = "Button13"
        Me.Button13.Size = New System.Drawing.Size(35, 35)
        Me.Button13.TabIndex = 9
        Me.Button13.Text = "F9"
        Me.Button13.UseVisualStyleBackColor = True
        '
        'Button16
        '
        Me.Button16.Location = New System.Drawing.Point(659, 12)
        Me.Button16.Name = "Button16"
        Me.Button16.Size = New System.Drawing.Size(48, 35)
        Me.Button16.TabIndex = 13
        Me.Button16.Text = "PrtScn"
        Me.Button16.UseVisualStyleBackColor = True
        '
        'Button14
        '
        Me.Button14.Location = New System.Drawing.Point(713, 12)
        Me.Button14.Name = "Button14"
        Me.Button14.Size = New System.Drawing.Size(48, 35)
        Me.Button14.TabIndex = 22
        Me.Button14.Text = "ScrLk"
        Me.Button14.UseVisualStyleBackColor = True
        '
        'Button15
        '
        Me.Button15.Location = New System.Drawing.Point(767, 12)
        Me.Button15.Name = "Button15"
        Me.Button15.Size = New System.Drawing.Size(48, 35)
        Me.Button15.TabIndex = 23
        Me.Button15.Text = "Pause"
        Me.Button15.UseVisualStyleBackColor = True
        '
        'Button17
        '
        Me.Button17.Location = New System.Drawing.Point(767, 78)
        Me.Button17.Name = "Button17"
        Me.Button17.Size = New System.Drawing.Size(48, 35)
        Me.Button17.TabIndex = 26
        Me.Button17.Text = "PG.Up"
        Me.Button17.UseVisualStyleBackColor = True
        '
        'Button18
        '
        Me.Button18.Location = New System.Drawing.Point(713, 78)
        Me.Button18.Name = "Button18"
        Me.Button18.Size = New System.Drawing.Size(48, 35)
        Me.Button18.TabIndex = 25
        Me.Button18.Text = "Home"
        Me.Button18.UseVisualStyleBackColor = True
        '
        'Button19
        '
        Me.Button19.Location = New System.Drawing.Point(659, 78)
        Me.Button19.Name = "Button19"
        Me.Button19.Size = New System.Drawing.Size(48, 35)
        Me.Button19.TabIndex = 24
        Me.Button19.Text = "Insert"
        Me.Button19.UseVisualStyleBackColor = True
        '
        'Button20
        '
        Me.Button20.Location = New System.Drawing.Point(767, 119)
        Me.Button20.Name = "Button20"
        Me.Button20.Size = New System.Drawing.Size(48, 35)
        Me.Button20.TabIndex = 29
        Me.Button20.Text = "PG.D"
        Me.Button20.UseVisualStyleBackColor = True
        '
        'Button21
        '
        Me.Button21.Location = New System.Drawing.Point(713, 119)
        Me.Button21.Name = "Button21"
        Me.Button21.Size = New System.Drawing.Size(48, 35)
        Me.Button21.TabIndex = 28
        Me.Button21.Text = "End"
        Me.Button21.UseVisualStyleBackColor = True
        '
        'Button22
        '
        Me.Button22.Location = New System.Drawing.Point(659, 119)
        Me.Button22.Name = "Button22"
        Me.Button22.Size = New System.Drawing.Size(48, 35)
        Me.Button22.TabIndex = 27
        Me.Button22.Text = "Delete"
        Me.Button22.UseVisualStyleBackColor = True
        '
        'Button23
        '
        Me.Button23.Location = New System.Drawing.Point(135, 53)
        Me.Button23.Name = "Button23"
        Me.Button23.Size = New System.Drawing.Size(35, 35)
        Me.Button23.TabIndex = 33
        Me.Button23.Text = "3"
        Me.Button23.UseVisualStyleBackColor = True
        '
        'Button24
        '
        Me.Button24.Location = New System.Drawing.Point(94, 53)
        Me.Button24.Name = "Button24"
        Me.Button24.Size = New System.Drawing.Size(35, 35)
        Me.Button24.TabIndex = 32
        Me.Button24.Text = "2"
        Me.Button24.UseVisualStyleBackColor = True
        '
        'Button25
        '
        Me.Button25.Location = New System.Drawing.Point(53, 53)
        Me.Button25.Name = "Button25"
        Me.Button25.Size = New System.Drawing.Size(35, 35)
        Me.Button25.TabIndex = 31
        Me.Button25.Text = "1"
        Me.Button25.UseVisualStyleBackColor = True
        '
        'Button26
        '
        Me.Button26.Location = New System.Drawing.Point(12, 53)
        Me.Button26.Name = "Button26"
        Me.Button26.Size = New System.Drawing.Size(35, 35)
        Me.Button26.TabIndex = 30
        Me.Button26.Text = "`¬"
        Me.Button26.UseVisualStyleBackColor = True
        '
        'Button27
        '
        Me.Button27.Location = New System.Drawing.Point(258, 53)
        Me.Button27.Name = "Button27"
        Me.Button27.Size = New System.Drawing.Size(35, 35)
        Me.Button27.TabIndex = 36
        Me.Button27.Text = "6"
        Me.Button27.UseVisualStyleBackColor = True
        '
        'Button28
        '
        Me.Button28.Location = New System.Drawing.Point(217, 53)
        Me.Button28.Name = "Button28"
        Me.Button28.Size = New System.Drawing.Size(35, 35)
        Me.Button28.TabIndex = 35
        Me.Button28.Text = "5"
        Me.Button28.UseVisualStyleBackColor = True
        '
        'Button29
        '
        Me.Button29.Location = New System.Drawing.Point(176, 53)
        Me.Button29.Name = "Button29"
        Me.Button29.Size = New System.Drawing.Size(35, 35)
        Me.Button29.TabIndex = 34
        Me.Button29.Text = "4"
        Me.Button29.UseVisualStyleBackColor = True
        '
        'Button30
        '
        Me.Button30.Location = New System.Drawing.Point(381, 53)
        Me.Button30.Name = "Button30"
        Me.Button30.Size = New System.Drawing.Size(35, 35)
        Me.Button30.TabIndex = 39
        Me.Button30.Text = "9"
        Me.Button30.UseVisualStyleBackColor = True
        '
        'Button31
        '
        Me.Button31.Location = New System.Drawing.Point(340, 53)
        Me.Button31.Name = "Button31"
        Me.Button31.Size = New System.Drawing.Size(35, 35)
        Me.Button31.TabIndex = 38
        Me.Button31.Text = "8"
        Me.Button31.UseVisualStyleBackColor = True
        '
        'Button32
        '
        Me.Button32.Location = New System.Drawing.Point(299, 53)
        Me.Button32.Name = "Button32"
        Me.Button32.Size = New System.Drawing.Size(35, 35)
        Me.Button32.TabIndex = 37
        Me.Button32.Text = "7"
        Me.Button32.UseVisualStyleBackColor = True
        '
        'Button33
        '
        Me.Button33.Location = New System.Drawing.Point(504, 53)
        Me.Button33.Name = "Button33"
        Me.Button33.Size = New System.Drawing.Size(35, 35)
        Me.Button33.TabIndex = 42
        Me.Button33.Text = "="
        Me.Button33.UseVisualStyleBackColor = True
        '
        'Button34
        '
        Me.Button34.Location = New System.Drawing.Point(463, 53)
        Me.Button34.Name = "Button34"
        Me.Button34.Size = New System.Drawing.Size(35, 35)
        Me.Button34.TabIndex = 41
        Me.Button34.Text = "-"
        Me.Button34.UseVisualStyleBackColor = True
        '
        'Button35
        '
        Me.Button35.Location = New System.Drawing.Point(422, 53)
        Me.Button35.Name = "Button35"
        Me.Button35.Size = New System.Drawing.Size(35, 35)
        Me.Button35.TabIndex = 40
        Me.Button35.Text = "0"
        Me.Button35.UseVisualStyleBackColor = True
        '
        'Button36
        '
        Me.Button36.Location = New System.Drawing.Point(545, 53)
        Me.Button36.Name = "Button36"
        Me.Button36.Size = New System.Drawing.Size(89, 35)
        Me.Button36.TabIndex = 43
        Me.Button36.Text = "<- backspace"
        Me.Button36.UseVisualStyleBackColor = True
        '
        'Button37
        '
        Me.Button37.Location = New System.Drawing.Point(12, 94)
        Me.Button37.Name = "Button37"
        Me.Button37.Size = New System.Drawing.Size(56, 35)
        Me.Button37.TabIndex = 44
        Me.Button37.Text = "tab"
        Me.Button37.UseVisualStyleBackColor = True
        '
        'Button38
        '
        Me.Button38.Location = New System.Drawing.Point(525, 94)
        Me.Button38.Name = "Button38"
        Me.Button38.Size = New System.Drawing.Size(35, 35)
        Me.Button38.TabIndex = 56
        Me.Button38.Text = "]"
        Me.Button38.UseVisualStyleBackColor = True
        '
        'Button39
        '
        Me.Button39.Location = New System.Drawing.Point(484, 94)
        Me.Button39.Name = "Button39"
        Me.Button39.Size = New System.Drawing.Size(35, 35)
        Me.Button39.TabIndex = 55
        Me.Button39.Text = "["
        Me.Button39.UseVisualStyleBackColor = True
        '
        'Button40
        '
        Me.Button40.Location = New System.Drawing.Point(443, 94)
        Me.Button40.Name = "Button40"
        Me.Button40.Size = New System.Drawing.Size(35, 35)
        Me.Button40.TabIndex = 54
        Me.Button40.Text = "P"
        Me.Button40.UseVisualStyleBackColor = True
        '
        'Button41
        '
        Me.Button41.Location = New System.Drawing.Point(402, 94)
        Me.Button41.Name = "Button41"
        Me.Button41.Size = New System.Drawing.Size(35, 35)
        Me.Button41.TabIndex = 53
        Me.Button41.Text = "O"
        Me.Button41.UseVisualStyleBackColor = True
        '
        'Button42
        '
        Me.Button42.Location = New System.Drawing.Point(361, 94)
        Me.Button42.Name = "Button42"
        Me.Button42.Size = New System.Drawing.Size(35, 35)
        Me.Button42.TabIndex = 52
        Me.Button42.Text = "I"
        Me.Button42.UseVisualStyleBackColor = True
        '
        'Button43
        '
        Me.Button43.Location = New System.Drawing.Point(320, 94)
        Me.Button43.Name = "Button43"
        Me.Button43.Size = New System.Drawing.Size(35, 35)
        Me.Button43.TabIndex = 51
        Me.Button43.Text = "U"
        Me.Button43.UseVisualStyleBackColor = True
        '
        'Button44
        '
        Me.Button44.Location = New System.Drawing.Point(279, 94)
        Me.Button44.Name = "Button44"
        Me.Button44.Size = New System.Drawing.Size(35, 35)
        Me.Button44.TabIndex = 50
        Me.Button44.Text = "Y"
        Me.Button44.UseVisualStyleBackColor = True
        '
        'Button45
        '
        Me.Button45.Location = New System.Drawing.Point(238, 94)
        Me.Button45.Name = "Button45"
        Me.Button45.Size = New System.Drawing.Size(35, 35)
        Me.Button45.TabIndex = 49
        Me.Button45.Text = "T"
        Me.Button45.UseVisualStyleBackColor = True
        '
        'Button46
        '
        Me.Button46.Location = New System.Drawing.Point(197, 94)
        Me.Button46.Name = "Button46"
        Me.Button46.Size = New System.Drawing.Size(35, 35)
        Me.Button46.TabIndex = 48
        Me.Button46.Text = "R"
        Me.Button46.UseVisualStyleBackColor = True
        '
        'Button47
        '
        Me.Button47.Location = New System.Drawing.Point(156, 94)
        Me.Button47.Name = "Button47"
        Me.Button47.Size = New System.Drawing.Size(35, 35)
        Me.Button47.TabIndex = 47
        Me.Button47.Text = "E"
        Me.Button47.UseVisualStyleBackColor = True
        '
        'Button48
        '
        Me.Button48.Location = New System.Drawing.Point(115, 94)
        Me.Button48.Name = "Button48"
        Me.Button48.Size = New System.Drawing.Size(35, 35)
        Me.Button48.TabIndex = 46
        Me.Button48.Text = "W"
        Me.Button48.UseVisualStyleBackColor = True
        '
        'Button49
        '
        Me.Button49.Location = New System.Drawing.Point(74, 94)
        Me.Button49.Name = "Button49"
        Me.Button49.Size = New System.Drawing.Size(35, 35)
        Me.Button49.TabIndex = 45
        Me.Button49.Text = "Q"
        Me.Button49.UseVisualStyleBackColor = True
        '
        'Button50
        '
        Me.Button50.Location = New System.Drawing.Point(525, 135)
        Me.Button50.Name = "Button50"
        Me.Button50.Size = New System.Drawing.Size(35, 35)
        Me.Button50.TabIndex = 69
        Me.Button50.Text = "#"
        Me.Button50.UseVisualStyleBackColor = True
        '
        'Button51
        '
        Me.Button51.Location = New System.Drawing.Point(484, 135)
        Me.Button51.Name = "Button51"
        Me.Button51.Size = New System.Drawing.Size(35, 35)
        Me.Button51.TabIndex = 68
        Me.Button51.Text = "@"
        Me.Button51.UseVisualStyleBackColor = True
        '
        'Button52
        '
        Me.Button52.Location = New System.Drawing.Point(443, 135)
        Me.Button52.Name = "Button52"
        Me.Button52.Size = New System.Drawing.Size(35, 35)
        Me.Button52.TabIndex = 67
        Me.Button52.Text = ";"
        Me.Button52.UseVisualStyleBackColor = True
        '
        'Button53
        '
        Me.Button53.Location = New System.Drawing.Point(402, 135)
        Me.Button53.Name = "Button53"
        Me.Button53.Size = New System.Drawing.Size(35, 35)
        Me.Button53.TabIndex = 66
        Me.Button53.Text = "L"
        Me.Button53.UseVisualStyleBackColor = True
        '
        'Button54
        '
        Me.Button54.Location = New System.Drawing.Point(361, 135)
        Me.Button54.Name = "Button54"
        Me.Button54.Size = New System.Drawing.Size(35, 35)
        Me.Button54.TabIndex = 65
        Me.Button54.Text = "K"
        Me.Button54.UseVisualStyleBackColor = True
        '
        'Button55
        '
        Me.Button55.Location = New System.Drawing.Point(320, 135)
        Me.Button55.Name = "Button55"
        Me.Button55.Size = New System.Drawing.Size(35, 35)
        Me.Button55.TabIndex = 64
        Me.Button55.Text = "J"
        Me.Button55.UseVisualStyleBackColor = True
        '
        'Button56
        '
        Me.Button56.Location = New System.Drawing.Point(279, 135)
        Me.Button56.Name = "Button56"
        Me.Button56.Size = New System.Drawing.Size(35, 35)
        Me.Button56.TabIndex = 63
        Me.Button56.Text = "H"
        Me.Button56.UseVisualStyleBackColor = True
        '
        'Button57
        '
        Me.Button57.Location = New System.Drawing.Point(238, 135)
        Me.Button57.Name = "Button57"
        Me.Button57.Size = New System.Drawing.Size(35, 35)
        Me.Button57.TabIndex = 62
        Me.Button57.Text = "G"
        Me.Button57.UseVisualStyleBackColor = True
        '
        'Button58
        '
        Me.Button58.Location = New System.Drawing.Point(197, 135)
        Me.Button58.Name = "Button58"
        Me.Button58.Size = New System.Drawing.Size(35, 35)
        Me.Button58.TabIndex = 61
        Me.Button58.Text = "F"
        Me.Button58.UseVisualStyleBackColor = True
        '
        'Button59
        '
        Me.Button59.Location = New System.Drawing.Point(156, 135)
        Me.Button59.Name = "Button59"
        Me.Button59.Size = New System.Drawing.Size(35, 35)
        Me.Button59.TabIndex = 60
        Me.Button59.Text = "D"
        Me.Button59.UseVisualStyleBackColor = True
        '
        'Button60
        '
        Me.Button60.Location = New System.Drawing.Point(115, 135)
        Me.Button60.Name = "Button60"
        Me.Button60.Size = New System.Drawing.Size(35, 35)
        Me.Button60.TabIndex = 59
        Me.Button60.Text = "S"
        Me.Button60.UseVisualStyleBackColor = True
        '
        'Button61
        '
        Me.Button61.Location = New System.Drawing.Point(74, 135)
        Me.Button61.Name = "Button61"
        Me.Button61.Size = New System.Drawing.Size(35, 35)
        Me.Button61.TabIndex = 58
        Me.Button61.Text = "A"
        Me.Button61.UseVisualStyleBackColor = True
        '
        'Button62
        '
        Me.Button62.Location = New System.Drawing.Point(12, 135)
        Me.Button62.Name = "Button62"
        Me.Button62.Size = New System.Drawing.Size(56, 35)
        Me.Button62.TabIndex = 57
        Me.Button62.Text = "CAPS"
        Me.Button62.UseVisualStyleBackColor = True
        '
        'Button63
        '
        Me.Button63.Location = New System.Drawing.Point(12, 176)
        Me.Button63.Name = "Button63"
        Me.Button63.Size = New System.Drawing.Size(35, 35)
        Me.Button63.TabIndex = 70
        Me.Button63.Text = "^"
        Me.Button63.UseVisualStyleBackColor = True
        '
        'Button65
        '
        Me.Button65.Location = New System.Drawing.Point(463, 176)
        Me.Button65.Name = "Button65"
        Me.Button65.Size = New System.Drawing.Size(35, 35)
        Me.Button65.TabIndex = 81
        Me.Button65.Text = "/"
        Me.Button65.UseVisualStyleBackColor = True
        '
        'Button66
        '
        Me.Button66.Location = New System.Drawing.Point(422, 176)
        Me.Button66.Name = "Button66"
        Me.Button66.Size = New System.Drawing.Size(35, 35)
        Me.Button66.TabIndex = 80
        Me.Button66.Text = "."
        Me.Button66.UseVisualStyleBackColor = True
        '
        'Button67
        '
        Me.Button67.Location = New System.Drawing.Point(381, 176)
        Me.Button67.Name = "Button67"
        Me.Button67.Size = New System.Drawing.Size(35, 35)
        Me.Button67.TabIndex = 79
        Me.Button67.Text = ","
        Me.Button67.UseVisualStyleBackColor = True
        '
        'Button68
        '
        Me.Button68.Location = New System.Drawing.Point(340, 176)
        Me.Button68.Name = "Button68"
        Me.Button68.Size = New System.Drawing.Size(35, 35)
        Me.Button68.TabIndex = 78
        Me.Button68.Text = "M"
        Me.Button68.UseVisualStyleBackColor = True
        '
        'Button69
        '
        Me.Button69.Location = New System.Drawing.Point(299, 176)
        Me.Button69.Name = "Button69"
        Me.Button69.Size = New System.Drawing.Size(35, 35)
        Me.Button69.TabIndex = 77
        Me.Button69.Text = "N"
        Me.Button69.UseVisualStyleBackColor = True
        '
        'Button70
        '
        Me.Button70.Location = New System.Drawing.Point(258, 176)
        Me.Button70.Name = "Button70"
        Me.Button70.Size = New System.Drawing.Size(35, 35)
        Me.Button70.TabIndex = 76
        Me.Button70.Text = "B"
        Me.Button70.UseVisualStyleBackColor = True
        '
        'Button71
        '
        Me.Button71.Location = New System.Drawing.Point(217, 176)
        Me.Button71.Name = "Button71"
        Me.Button71.Size = New System.Drawing.Size(35, 35)
        Me.Button71.TabIndex = 75
        Me.Button71.Text = "V"
        Me.Button71.UseVisualStyleBackColor = True
        '
        'Button72
        '
        Me.Button72.Location = New System.Drawing.Point(176, 176)
        Me.Button72.Name = "Button72"
        Me.Button72.Size = New System.Drawing.Size(35, 35)
        Me.Button72.TabIndex = 74
        Me.Button72.Text = "C"
        Me.Button72.UseVisualStyleBackColor = True
        '
        'Button73
        '
        Me.Button73.Location = New System.Drawing.Point(135, 176)
        Me.Button73.Name = "Button73"
        Me.Button73.Size = New System.Drawing.Size(35, 35)
        Me.Button73.TabIndex = 73
        Me.Button73.Text = "X"
        Me.Button73.UseVisualStyleBackColor = True
        '
        'Button74
        '
        Me.Button74.Location = New System.Drawing.Point(94, 176)
        Me.Button74.Name = "Button74"
        Me.Button74.Size = New System.Drawing.Size(35, 35)
        Me.Button74.TabIndex = 72
        Me.Button74.Text = "Z"
        Me.Button74.UseVisualStyleBackColor = True
        '
        'Button75
        '
        Me.Button75.Location = New System.Drawing.Point(53, 176)
        Me.Button75.Name = "Button75"
        Me.Button75.Size = New System.Drawing.Size(35, 35)
        Me.Button75.TabIndex = 71
        Me.Button75.Text = "\"
        Me.Button75.UseVisualStyleBackColor = True
        '
        'Button76
        '
        Me.Button76.Location = New System.Drawing.Point(504, 176)
        Me.Button76.Name = "Button76"
        Me.Button76.Size = New System.Drawing.Size(130, 35)
        Me.Button76.TabIndex = 83
        Me.Button76.Text = "Shift"
        Me.Button76.UseVisualStyleBackColor = True
        '
        'Button77
        '
        Me.Button77.Location = New System.Drawing.Point(564, 94)
        Me.Button77.Name = "Button77"
        Me.Button77.Size = New System.Drawing.Size(70, 76)
        Me.Button77.TabIndex = 84
        Me.Button77.Text = "Enter"
        Me.Button77.UseVisualStyleBackColor = True
        '
        'Button78
        '
        Me.Button78.Location = New System.Drawing.Point(12, 217)
        Me.Button78.Name = "Button78"
        Me.Button78.Size = New System.Drawing.Size(56, 35)
        Me.Button78.TabIndex = 85
        Me.Button78.Text = "CTRL"
        Me.Button78.UseVisualStyleBackColor = True
        '
        'Button79
        '
        Me.Button79.Location = New System.Drawing.Point(74, 217)
        Me.Button79.Name = "Button79"
        Me.Button79.Size = New System.Drawing.Size(56, 35)
        Me.Button79.TabIndex = 86
        Me.Button79.Text = "WIN"
        Me.Button79.UseVisualStyleBackColor = True
        '
        'Button80
        '
        Me.Button80.Location = New System.Drawing.Point(135, 217)
        Me.Button80.Name = "Button80"
        Me.Button80.Size = New System.Drawing.Size(56, 35)
        Me.Button80.TabIndex = 87
        Me.Button80.Text = "ALT"
        Me.Button80.UseVisualStyleBackColor = True
        '
        'Button81
        '
        Me.Button81.Location = New System.Drawing.Point(578, 217)
        Me.Button81.Name = "Button81"
        Me.Button81.Size = New System.Drawing.Size(56, 35)
        Me.Button81.TabIndex = 90
        Me.Button81.Text = "CTRL"
        Me.Button81.UseVisualStyleBackColor = True
        '
        'Button82
        '
        Me.Button82.Location = New System.Drawing.Point(517, 217)
        Me.Button82.Name = "Button82"
        Me.Button82.Size = New System.Drawing.Size(56, 35)
        Me.Button82.TabIndex = 89
        Me.Button82.Text = "RC"
        Me.Button82.UseVisualStyleBackColor = True
        '
        'Button83
        '
        Me.Button83.Location = New System.Drawing.Point(455, 217)
        Me.Button83.Name = "Button83"
        Me.Button83.Size = New System.Drawing.Size(56, 35)
        Me.Button83.TabIndex = 88
        Me.Button83.Text = "WIN"
        Me.Button83.UseVisualStyleBackColor = True
        '
        'Button84
        '
        Me.Button84.Location = New System.Drawing.Point(393, 217)
        Me.Button84.Name = "Button84"
        Me.Button84.Size = New System.Drawing.Size(56, 35)
        Me.Button84.TabIndex = 91
        Me.Button84.Text = "ALT GR"
        Me.Button84.UseVisualStyleBackColor = True
        '
        'Button85
        '
        Me.Button85.Location = New System.Drawing.Point(197, 217)
        Me.Button85.Name = "Button85"
        Me.Button85.Size = New System.Drawing.Size(190, 35)
        Me.Button85.TabIndex = 92
        Me.Button85.Text = "SPACE"
        Me.Button85.UseVisualStyleBackColor = True
        '
        'Button64
        '
        Me.Button64.Location = New System.Drawing.Point(767, 217)
        Me.Button64.Name = "Button64"
        Me.Button64.Size = New System.Drawing.Size(48, 35)
        Me.Button64.TabIndex = 96
        Me.Button64.Text = ">"
        Me.Button64.UseVisualStyleBackColor = True
        '
        'Button86
        '
        Me.Button86.Location = New System.Drawing.Point(713, 217)
        Me.Button86.Name = "Button86"
        Me.Button86.Size = New System.Drawing.Size(48, 35)
        Me.Button86.TabIndex = 95
        Me.Button86.Text = "V"
        Me.Button86.UseVisualStyleBackColor = True
        '
        'Button87
        '
        Me.Button87.Location = New System.Drawing.Point(659, 217)
        Me.Button87.Name = "Button87"
        Me.Button87.Size = New System.Drawing.Size(48, 35)
        Me.Button87.TabIndex = 94
        Me.Button87.Text = "<"
        Me.Button87.UseVisualStyleBackColor = True
        '
        'Button88
        '
        Me.Button88.Location = New System.Drawing.Point(713, 176)
        Me.Button88.Name = "Button88"
        Me.Button88.Size = New System.Drawing.Size(48, 35)
        Me.Button88.TabIndex = 93
        Me.Button88.Text = "^"
        Me.Button88.UseVisualStyleBackColor = True
        '
        'Keyboard
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(831, 268)
        Me.Controls.Add(Me.Button64)
        Me.Controls.Add(Me.Button86)
        Me.Controls.Add(Me.Button87)
        Me.Controls.Add(Me.Button88)
        Me.Controls.Add(Me.Button85)
        Me.Controls.Add(Me.Button84)
        Me.Controls.Add(Me.Button81)
        Me.Controls.Add(Me.Button82)
        Me.Controls.Add(Me.Button83)
        Me.Controls.Add(Me.Button80)
        Me.Controls.Add(Me.Button79)
        Me.Controls.Add(Me.Button78)
        Me.Controls.Add(Me.Button77)
        Me.Controls.Add(Me.Button76)
        Me.Controls.Add(Me.Button65)
        Me.Controls.Add(Me.Button66)
        Me.Controls.Add(Me.Button67)
        Me.Controls.Add(Me.Button68)
        Me.Controls.Add(Me.Button69)
        Me.Controls.Add(Me.Button70)
        Me.Controls.Add(Me.Button71)
        Me.Controls.Add(Me.Button72)
        Me.Controls.Add(Me.Button73)
        Me.Controls.Add(Me.Button74)
        Me.Controls.Add(Me.Button75)
        Me.Controls.Add(Me.Button63)
        Me.Controls.Add(Me.Button50)
        Me.Controls.Add(Me.Button51)
        Me.Controls.Add(Me.Button52)
        Me.Controls.Add(Me.Button53)
        Me.Controls.Add(Me.Button54)
        Me.Controls.Add(Me.Button55)
        Me.Controls.Add(Me.Button56)
        Me.Controls.Add(Me.Button57)
        Me.Controls.Add(Me.Button58)
        Me.Controls.Add(Me.Button59)
        Me.Controls.Add(Me.Button60)
        Me.Controls.Add(Me.Button61)
        Me.Controls.Add(Me.Button62)
        Me.Controls.Add(Me.Button38)
        Me.Controls.Add(Me.Button39)
        Me.Controls.Add(Me.Button40)
        Me.Controls.Add(Me.Button41)
        Me.Controls.Add(Me.Button42)
        Me.Controls.Add(Me.Button43)
        Me.Controls.Add(Me.Button44)
        Me.Controls.Add(Me.Button45)
        Me.Controls.Add(Me.Button46)
        Me.Controls.Add(Me.Button47)
        Me.Controls.Add(Me.Button48)
        Me.Controls.Add(Me.Button49)
        Me.Controls.Add(Me.Button37)
        Me.Controls.Add(Me.Button36)
        Me.Controls.Add(Me.Button33)
        Me.Controls.Add(Me.Button34)
        Me.Controls.Add(Me.Button35)
        Me.Controls.Add(Me.Button30)
        Me.Controls.Add(Me.Button31)
        Me.Controls.Add(Me.Button32)
        Me.Controls.Add(Me.Button27)
        Me.Controls.Add(Me.Button28)
        Me.Controls.Add(Me.Button29)
        Me.Controls.Add(Me.Button23)
        Me.Controls.Add(Me.Button24)
        Me.Controls.Add(Me.Button25)
        Me.Controls.Add(Me.Button26)
        Me.Controls.Add(Me.Button20)
        Me.Controls.Add(Me.Button21)
        Me.Controls.Add(Me.Button22)
        Me.Controls.Add(Me.Button17)
        Me.Controls.Add(Me.Button18)
        Me.Controls.Add(Me.Button19)
        Me.Controls.Add(Me.Button15)
        Me.Controls.Add(Me.Button14)
        Me.Controls.Add(Me.Button16)
        Me.Controls.Add(Me.Button10)
        Me.Controls.Add(Me.Button11)
        Me.Controls.Add(Me.Button12)
        Me.Controls.Add(Me.Button13)
        Me.Controls.Add(Me.Button6)
        Me.Controls.Add(Me.Button7)
        Me.Controls.Add(Me.Button8)
        Me.Controls.Add(Me.Button9)
        Me.Controls.Add(Me.Button5)
        Me.Controls.Add(Me.Button4)
        Me.Controls.Add(Me.Button3)
        Me.Controls.Add(Me.Button2)
        Me.Controls.Add(Me.Button1)
        Me.MaximumSize = New System.Drawing.Size(847, 307)
        Me.MinimumSize = New System.Drawing.Size(847, 307)
        Me.Name = "Keyboard"
        Me.Text = "Keyboard"
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents Button1 As Button
    Friend WithEvents Button2 As Button
    Friend WithEvents Button3 As Button
    Friend WithEvents Button4 As Button
    Friend WithEvents Button5 As Button
    Friend WithEvents Button6 As Button
    Friend WithEvents Button7 As Button
    Friend WithEvents Button8 As Button
    Friend WithEvents Button9 As Button
    Friend WithEvents Button10 As Button
    Friend WithEvents Button11 As Button
    Friend WithEvents Button12 As Button
    Friend WithEvents Button13 As Button
    Friend WithEvents Button16 As Button
    Friend WithEvents Button14 As Button
    Friend WithEvents Button15 As Button
    Friend WithEvents Button17 As Button
    Friend WithEvents Button18 As Button
    Friend WithEvents Button19 As Button
    Friend WithEvents Button20 As Button
    Friend WithEvents Button21 As Button
    Friend WithEvents Button22 As Button
    Friend WithEvents Button23 As Button
    Friend WithEvents Button24 As Button
    Friend WithEvents Button25 As Button
    Friend WithEvents Button26 As Button
    Friend WithEvents Button27 As Button
    Friend WithEvents Button28 As Button
    Friend WithEvents Button29 As Button
    Friend WithEvents Button30 As Button
    Friend WithEvents Button31 As Button
    Friend WithEvents Button32 As Button
    Friend WithEvents Button33 As Button
    Friend WithEvents Button34 As Button
    Friend WithEvents Button35 As Button
    Friend WithEvents Button36 As Button
    Friend WithEvents Button37 As Button
    Friend WithEvents Button38 As Button
    Friend WithEvents Button39 As Button
    Friend WithEvents Button40 As Button
    Friend WithEvents Button41 As Button
    Friend WithEvents Button42 As Button
    Friend WithEvents Button43 As Button
    Friend WithEvents Button44 As Button
    Friend WithEvents Button45 As Button
    Friend WithEvents Button46 As Button
    Friend WithEvents Button47 As Button
    Friend WithEvents Button48 As Button
    Friend WithEvents Button49 As Button
    Friend WithEvents Button50 As Button
    Friend WithEvents Button51 As Button
    Friend WithEvents Button52 As Button
    Friend WithEvents Button53 As Button
    Friend WithEvents Button54 As Button
    Friend WithEvents Button55 As Button
    Friend WithEvents Button56 As Button
    Friend WithEvents Button57 As Button
    Friend WithEvents Button58 As Button
    Friend WithEvents Button59 As Button
    Friend WithEvents Button60 As Button
    Friend WithEvents Button61 As Button
    Friend WithEvents Button62 As Button
    Friend WithEvents Button63 As Button
    Friend WithEvents Button65 As Button
    Friend WithEvents Button66 As Button
    Friend WithEvents Button67 As Button
    Friend WithEvents Button68 As Button
    Friend WithEvents Button69 As Button
    Friend WithEvents Button70 As Button
    Friend WithEvents Button71 As Button
    Friend WithEvents Button72 As Button
    Friend WithEvents Button73 As Button
    Friend WithEvents Button74 As Button
    Friend WithEvents Button75 As Button
    Friend WithEvents Button76 As Button
    Friend WithEvents Button77 As Button
    Friend WithEvents Button78 As Button
    Friend WithEvents Button79 As Button
    Friend WithEvents Button80 As Button
    Friend WithEvents Button81 As Button
    Friend WithEvents Button82 As Button
    Friend WithEvents Button83 As Button
    Friend WithEvents Button84 As Button
    Friend WithEvents Button85 As Button
    Friend WithEvents Button64 As Button
    Friend WithEvents Button86 As Button
    Friend WithEvents Button87 As Button
    Friend WithEvents Button88 As Button
End Class
